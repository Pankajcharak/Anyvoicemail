package com.example.voicemailctl;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final int PICK = 1, PERM = 2;
    private SharedPreferences sp;
    private EditText token, chat, delay, text, lang;
    private TextView status, logView;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16); root.setPadding(p, p, p, p);
        sv.addView(root);

        label(root, "1. Telegram");
        token = field(root, "Bot token", "token", "", true);
        chat = field(root, "Your chat ID", "chat", "", false);
        btn(root, "Send Telegram test", v -> telegramTest());

        label(root, "2. Greeting");
        delay = field(root, "Ring seconds before answering (use 12)", "delay", "12", false);
        delay.setInputType(InputType.TYPE_CLASS_NUMBER);
        text = field(root, "Greeting text", "text",
                "Hi, I'm currently unavailable. Please leave your message after the beep.", false);
        lang = field(root, "Voice language (en-IN or hi-IN)", "lang", "en-IN", false);
        btn(root, "Use my own MP3 greeting (optional)", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("audio/*");
            startActivityForResult(i, PICK);
        });
        btn(root, "Remove MP3 (use text greeting)", v -> {
            new File(getFilesDir(), "greeting.mp3").delete(); msg("MP3 removed.");
        });

        label(root, "3. Run");
        btn(root, "START auto voicemail", v -> startSvc());
        btn(root, "STOP", v -> { stopService(new Intent(this, VoicemailService.class)); msg("Stopped."); });
        btn(root, "Allow background running (battery)", v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));

        btn(root, "Allow notification access (backup answer method)", v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));

        btn(root, "Enable accessibility (strongest backup)", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        label(root, "4. Diagnostics");
        btn(root, "Check status", v -> checkStatus());
        btn(root, "Refresh log", v -> logView.setText(VmLog.get(this)));
        btn(root, "Copy log", v -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                    .setPrimaryClip(ClipData.newPlainText("log", VmLog.get(this)));
            msg("Log copied.");
        });
        btn(root, "Clear log", v -> { VmLog.clear(this); logView.setText(""); });

        status = new TextView(this);
        status.setPadding(0, dp(12), 0, 0);
        root.addView(status);
        logView = new TextView(this);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextSize(12);
        logView.setTextIsSelectable(true);
        root.addView(logView);
        setContentView(sv);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void label(LinearLayout r, String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(18); t.setPadding(0, dp(16), 0, dp(4));
        r.addView(t);
    }

    private EditText field(LinearLayout r, String hint, String key, String def, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(sp.getString(key, def));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        r.addView(e);
        return e;
    }

    private void btn(LinearLayout r, String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setOnClickListener(l);
        r.addView(b);
    }

    @Override protected void onResume() {
        super.onResume();
        if (logView != null) logView.setText(VmLog.get(this));
    }

    private void checkStatus() {
        StringBuilder s = new StringBuilder();
        s.append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        String[] ps = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_CALL_LOG};
        for (String p : ps)
            s.append(p.substring(p.lastIndexOf('.') + 1)).append(": ")
                    .append(checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED ? "YES" : "NO").append('\n');
        s.append("Service running: ").append(VoicemailService.running ? "YES" : "NO").append('\n');
        String en = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        s.append("Notification access: ").append(en != null && en.contains(getPackageName()) ? "YES" : "NO").append('\n');
        String ea = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
        s.append("Accessibility: ").append(ea != null && ea.contains(getPackageName()) ? "YES" : "NO").append('\n');
        s.append("Battery unrestricted: ").append(((PowerManager) getSystemService(POWER_SERVICE))
                .isIgnoringBatteryOptimizations(getPackageName()) ? "YES" : "NO");
        msg(s.toString());
        VmLog.add(this, "STATUS " + s.toString().replace('\n', '|'));
        logView.setText(VmLog.get(this));
    }

    private void msg(String s) { runOnUiThread(() -> status.setText(s)); }

    private void save() {
        sp.edit().putString("token", token.getText().toString().trim())
                .putString("chat", chat.getText().toString().trim())
                .putString("delay", delay.getText().toString().trim())
                .putString("text", text.getText().toString().trim())
                .putString("lang", lang.getText().toString().trim()).apply();
    }

    // ---------- permissions + start ----------
    private boolean core() {
        String[] need = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS};
        for (String p : need)
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }

    private void startSvc() {
        save();
        if (token.getText().length() < 10 || chat.getText().length() < 3) {
            msg("Enter bot token and chat ID first."); return;
        }
        if (!core()) {
            String[] all = Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_CALL_LOG,
                    "android.permission.POST_NOTIFICATIONS"}
                    : new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_CALL_LOG};
            requestPermissions(all, PERM);
            return;
        }
        startForegroundService(new Intent(this, VoicemailService.class));
        msg("Auto voicemail is ON. Unanswered calls will be picked up after "
                + delay.getText() + "s.");
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (core()) startSvc();
        else msg("Please allow Microphone, Phone and Answer-calls permissions in app settings.");
    }

    // ---------- MP3 greeting ----------
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || res != RESULT_OK || data == null) return;
        try {
            InputStream in = getContentResolver().openInputStream(data.getData());
            OutputStream out = new FileOutputStream(new File(getFilesDir(), "greeting.mp3"));
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close(); out.close();
            msg("MP3 greeting saved.");
        } catch (Exception e) { msg("Could not read file: " + e); }
    }

    // ---------- Telegram test ----------
    private void telegramTest() {
        save();
        msg("Sending...");
        new Thread(() -> {
            try {
                String body = "chat_id=" + URLEncoder.encode(chat.getText().toString().trim(), "UTF-8")
                        + "&text=" + URLEncoder.encode("Auto Voicemail test OK", "UTF-8");
                HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot"
                        + token.getText().toString().trim() + "/sendMessage").openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true);
                c.setConnectTimeout(15000); c.setReadTimeout(30000);
                c.getOutputStream().write(body.getBytes("UTF-8"));
                int code = c.getResponseCode();
                msg(code == 200 ? "Telegram OK - check your bot chat."
                        : "Telegram error " + code + ". Check token / chat ID, and press Start in the bot chat.");
            } catch (Exception e) { msg("Error: " + e); }
        }).start();
    }
}
