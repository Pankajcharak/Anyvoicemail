package com.example.voicemailctl;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.telephony.TelephonyCallback;
import android.view.KeyEvent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telecom.TelecomManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class VoicemailService extends Service {
    private static final String CH = "vm";
    private final Handler h = new Handler(Looper.getMainLooper());
    private TelephonyManager tm;
    private TelecomManager tc;
    private AudioManager am;
    private PhoneStateListener listener;
    private SharedPreferences sp;
    private TextToSpeech tts;
    private boolean ttsReady;
    private MediaPlayer mp;
    private MediaRecorder rec;
    private File recFile;
    private boolean ringing, weAnswered, recording;
    private String number = "Unknown";
    private long startedAt;
    static volatile boolean running;
    private Object newCb;

    private final Runnable answer = this::answerStep1;
    private final Runnable answer2 = this::answerStep2;
    private final Runnable answer3 = this::answerStep3;
    private final Runnable answer4 = this::answerStep4;
    private final Runnable answerFail = this::answerFailed;

    private void answerStep1() {
        if (!ringing) return;
        weAnswered = true;
        VmLog.add(this, "Answer method 1: TelecomManager.acceptRingingCall");
        try { tc.acceptRingingCall(); } catch (Exception e) { VmLog.add(this, "method 1 error: " + e); }
        h.postDelayed(answer2, 1500);
    }

    private void answerStep2() {
        if (!ringing) return;
        VmLog.add(this, "Still ringing. Answer method 2: headset hook key");
        try {
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK));
            am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK));
        } catch (Exception e) { VmLog.add(this, "method 2 error: " + e); }
        h.postDelayed(answer3, 1500);
    }

    private void answerStep3() {
        if (!ringing) return;
        VmLog.add(this, "Still ringing. Answer method 3: notification Answer button");
        boolean ok = CallNotificationListener.answer(this);
        VmLog.add(this, "method 3 result: " + ok);
        h.postDelayed(answer4, 1500);
    }

    private void answerStep4() {
        if (!ringing) return;
        VmLog.add(this, "Still ringing. Answer method 4: accessibility tap");
        boolean ok = AnswerAccessibilityService.answer(this);
        VmLog.add(this, "method 4 result: " + ok);
        h.postDelayed(answerFail, 2000);
    }

    private void answerFailed() {
        if (!ringing) return;
        weAnswered = false;
        VmLog.add(this, "FAILED: could not answer. Press Check status and share the log.");
    }

    private final Runnable greet = this::playGreeting;
    private final Runnable beepRec = this::startRec;
    private final Runnable hardStop = () -> {
        if (Build.VERSION.SDK_INT >= 28) { try { tc.endCall(); } catch (Exception e) { } }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        tc = (TelecomManager) getSystemService(TELECOM_SERVICE);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        tts = new TextToSpeech(this, st -> ttsReady = (st == TextToSpeech.SUCCESS));
        running = true;
        VmLog.add(this, "Service started, API " + Build.VERSION.SDK_INT);
        listener = new PhoneStateListener() {
            @Override public void onCallStateChanged(int state, String num) { onState(state, num); }
        };
        tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                CallCb cb = new CallCb();
                tm.registerTelephonyCallback(getMainExecutor(), cb);
                newCb = cb;
            } catch (Exception e) { VmLog.add(this, "registerTelephonyCallback error: " + e); }
        }
    }

    private class CallCb extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        @Override public void onCallStateChanged(int state) { onState(state, null); }
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH, "Auto Voicemail", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CH)
                .setContentTitle("Auto Voicemail is ON")
                .setContentText("Unanswered calls will be picked up")
                .setSmallIcon(android.R.drawable.ic_menu_call).build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        else startForeground(1, n);
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        VmLog.add(this, "Service stopped");
        if (Build.VERSION.SDK_INT >= 31 && newCb != null) tm.unregisterTelephonyCallback((TelephonyCallback) newCb);
        tm.listen(listener, PhoneStateListener.LISTEN_NONE);
        h.removeCallbacksAndMessages(null);
        if (recording) finishRecording();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    // ---------- call state machine ----------
    private int delaySec() {
        try { return Math.max(3, Integer.parseInt(sp.getString("delay", "12"))); }
        catch (Exception e) { return 12; }
    }

    private void cancelAnswer() {
        h.removeCallbacks(answer); h.removeCallbacks(answer2);
        h.removeCallbacks(answer3); h.removeCallbacks(answer4); h.removeCallbacks(answerFail);
    }

    private void onState(int state, String num) {
        VmLog.add(this, "state=" + (state == 1 ? "RINGING" : state == 2 ? "OFFHOOK" : "IDLE"));
        if (state == TelephonyManager.CALL_STATE_RINGING) {
            if (num != null && !num.isEmpty()) number = num;
            if (!ringing) {
                ringing = true; weAnswered = false;
                VmLog.add(this, "Ringing; will answer in " + delaySec() + "s");
                h.postDelayed(answer, delaySec() * 1000L);
            }
        } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
            ringing = false;
            cancelAnswer();
            if (weAnswered && !recording) { h.removeCallbacks(greet); h.postDelayed(greet, 900); }
        } else { // IDLE
            ringing = false;
            cancelAnswer(); h.removeCallbacks(greet);
            h.removeCallbacks(beepRec); h.removeCallbacks(hardStop);
            stopAudio();
            if (recording) finishRecording();
            if (weAnswered) am.setSpeakerphoneOn(false);
            weAnswered = false;
            number = "Unknown";
        }
    }

    // ---------- greeting ----------
    private void playGreeting() {
        if (!weAnswered) return;
        VmLog.add(this, "Call answered; playing greeting");
        try {
            am.setSpeakerphoneOn(true);
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                    am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            File g = new File(getFilesDir(), "greeting.mp3");
            if (g.exists()) {
                mp = new MediaPlayer();
                mp.setAudioAttributes(aa);
                mp.setDataSource(g.getPath());
                mp.setOnCompletionListener(m -> beepThenRecord());
                mp.prepare();
                mp.start();
            } else if (ttsReady) {
                tts.setAudioAttributes(aa);
                tts.setLanguage(Locale.forLanguageTag(sp.getString("lang", "en-IN")));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { h.post(() -> beepThenRecord()); }
                    @Override public void onError(String id) { h.post(() -> beepThenRecord()); }
                });
                tts.speak(sp.getString("text", "Please leave a message after the beep."),
                        TextToSpeech.QUEUE_FLUSH, null, "g");
            } else beepThenRecord();
        } catch (Exception e) { beepThenRecord(); }
    }

    private void stopAudio() {
        try { if (mp != null) { mp.release(); mp = null; } } catch (Exception e) { }
        try { if (tts != null) tts.stop(); } catch (Exception e) { }
    }

    private void beepThenRecord() {
        if (!weAnswered || recording) return;
        try { new ToneGenerator(AudioManager.STREAM_VOICE_CALL, 100).startTone(ToneGenerator.TONE_PROP_BEEP, 400); }
        catch (Exception e) { }
        h.postDelayed(beepRec, 700);
    }

    // ---------- recording ----------
    private void startRec() {
        if (!weAnswered || recording) return;
        try {
            recFile = new File(getCacheDir(), "vm_" + System.currentTimeMillis() + ".m4a");
            rec = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            rec.setAudioSource(MediaRecorder.AudioSource.MIC);
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            rec.setAudioEncodingBitRate(64000);
            rec.setAudioSamplingRate(16000);
            rec.setOutputFile(recFile.getPath());
            rec.prepare();
            rec.start();
            recording = true;
            VmLog.add(this, "Recording started");
            startedAt = System.currentTimeMillis();
            h.postDelayed(hardStop, 180000);
        } catch (Exception e) { recording = false; VmLog.add(this, "Recording error: " + e); }
    }

    private void finishRecording() {
        recording = false;
        try { rec.stop(); } catch (Exception e) { }
        try { rec.release(); } catch (Exception e) { }
        rec = null;
        final File f = recFile;
        final String who = number;
        final long dur = (System.currentTimeMillis() - startedAt) / 1000;
        if (f != null && f.exists() && f.length() > 1000)
            new Thread(() -> upload(f, who, dur)).start();
    }

    // ---------- Telegram upload ----------
    private void upload(File f, String who, long dur) {
        try {
            String B = "----vm" + System.currentTimeMillis();
            ByteArrayOutputStream body = new ByteArrayOutputStream();
            part(body, B, "chat_id", sp.getString("chat", ""));
            part(body, B, "caption", "\uD83D\uDCDE " + who + "\n\u23F1 " + dur + "s");
            body.write(("--" + B + "\r\nContent-Disposition: form-data; name=\"audio\"; filename=\""
                    + f.getName() + "\"\r\nContent-Type: audio/mp4\r\n\r\n").getBytes("UTF-8"));
            InputStream in = new FileInputStream(f);
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) body.write(buf, 0, n);
            in.close();
            body.write(("\r\n--" + B + "--\r\n").getBytes("UTF-8"));
            byte[] data = body.toByteArray();
            HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot"
                    + sp.getString("token", "") + "/sendAudio").openConnection();
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setConnectTimeout(20000); c.setReadTimeout(60000);
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + B);
            c.setFixedLengthStreamingMode(data.length);
            OutputStream os = c.getOutputStream(); os.write(data); os.close();
            int code = c.getResponseCode();
            VmLog.add(this, "Telegram upload HTTP " + code);
            if (code == 200) f.delete();
        } catch (Exception e) { VmLog.add(this, "Upload error: " + e); }
    }

    private void part(ByteArrayOutputStream o, String B, String k, String v) throws Exception {
        o.write(("--" + B + "\r\nContent-Disposition: form-data; name=\"" + k + "\"\r\n\r\n" + v + "\r\n").getBytes("UTF-8"));
    }
}
