package com.example.voicemailctl;

import android.app.Notification;
import android.content.Context;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class CallNotificationListener extends NotificationListenerService {
    static volatile CallNotificationListener inst;

    @Override public void onListenerConnected() { inst = this; }
    @Override public void onListenerDisconnected() { inst = null; }

    /** Taps the "Answer" button of the incoming-call notification. */
    static boolean answer(Context ctx) {
        CallNotificationListener l = inst;
        if (l == null) { VmLog.add(ctx, "notif: access not enabled"); return false; }
        try {
            for (StatusBarNotification sbn : l.getActiveNotifications()) {
                Notification n = sbn.getNotification();
                if (n.actions == null) continue;
                StringBuilder titles = new StringBuilder();
                Notification.Action pick = null;
                for (Notification.Action a : n.actions) {
                    String t = String.valueOf(a.title);
                    titles.append(t).append(',');
                    String lt = t.toLowerCase();
                    if (lt.contains("answer") || lt.contains("accept") || lt.contains("pick")) pick = a;
                }
                VmLog.add(ctx, "notif " + sbn.getPackageName() + " cat=" + n.category + " actions=" + titles);
                if (pick != null && (Notification.CATEGORY_CALL.equals(n.category)
                        || sbn.getPackageName().contains("dialer") || sbn.getPackageName().contains("incall")
                        || sbn.getPackageName().contains("phone") || sbn.getPackageName().contains("telecom"))) {
                    pick.actionIntent.send();
                    return true;
                }
            }
        } catch (Exception e) { VmLog.add(ctx, "notif error " + e); }
        return false;
    }
}
