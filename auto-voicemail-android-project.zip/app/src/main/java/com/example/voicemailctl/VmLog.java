package com.example.voicemailctl;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class VmLog {
    static synchronized void add(Context c, String s) {
        SharedPreferences sp = c.getSharedPreferences("log", Context.MODE_PRIVATE);
        String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + s + "\n";
        String all = sp.getString("l", "") + line;
        if (all.length() > 6000) all = all.substring(all.length() - 6000);
        sp.edit().putString("l", all).apply();
    }
    static String get(Context c) { return c.getSharedPreferences("log", Context.MODE_PRIVATE).getString("l", ""); }
    static void clear(Context c) { c.getSharedPreferences("log", Context.MODE_PRIVATE).edit().clear().apply(); }
}
