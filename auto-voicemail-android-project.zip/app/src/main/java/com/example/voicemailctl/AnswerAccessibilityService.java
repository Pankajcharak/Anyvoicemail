package com.example.voicemailctl;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

public class AnswerAccessibilityService extends AccessibilityService {
    static volatile AnswerAccessibilityService inst;

    @Override protected void onServiceConnected() { inst = this; }
    @Override public boolean onUnbind(Intent i) { inst = null; return super.onUnbind(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    private static final String[] WORDS = {"answer", "accept", "pick up", "\u0909\u0924\u094d\u0924\u0930", "\u091c\u0935\u093e\u092c", "\u0938\u094d\u0935\u0940\u0915\u093e\u0930"};

    /** Finds and taps the Answer button on screen (dialer UI or heads-up notification). */
    static boolean answer(Context ctx) {
        AnswerAccessibilityService s = inst;
        if (s == null) { VmLog.add(ctx, "a11y: service not enabled"); return false; }
        try {
            List<AccessibilityWindowInfo> wins = s.getWindows();
            VmLog.add(ctx, "a11y: windows=" + (wins == null ? 0 : wins.size()));
            if (wins != null) for (AccessibilityWindowInfo w : wins) {
                AccessibilityNodeInfo root = w.getRoot();
                if (root != null && tap(ctx, root)) return true;
            }
            AccessibilityNodeInfo r = s.getRootInActiveWindow();
            if (r != null && tap(ctx, r)) return true;
        } catch (Exception e) { VmLog.add(ctx, "a11y error " + e); }
        return false;
    }

    private static boolean tap(Context ctx, AccessibilityNodeInfo root) {
        for (String w : WORDS) {
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(w);
            if (l != null) for (AccessibilityNodeInfo n : l) {
                if (click(ctx, n, w)) return true;
            }
        }
        return byId(ctx, root);
    }

    private static boolean byId(Context ctx, AccessibilityNodeInfo n) {
        if (n == null) return false;
        String id = n.getViewIdResourceName();
        if (id != null && (id.toLowerCase().contains("answer") || id.toLowerCase().contains("accept"))
                && click(ctx, n, "id:" + id)) return true;
        for (int i = 0; i < n.getChildCount(); i++)
            if (byId(ctx, n.getChild(i))) return true;
        return false;
    }

    private static boolean click(Context ctx, AccessibilityNodeInfo n, String why) {
        AccessibilityNodeInfo c = n;
        while (c != null) {
            if (c.isClickable() && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                VmLog.add(ctx, "a11y: clicked (" + why + ")");
                return true;
            }
            c = c.getParent();
        }
        return false;
    }
}
