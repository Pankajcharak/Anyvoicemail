# Auto Voicemail (Android)
Answers unanswered calls after N seconds, plays a greeting, records, sends the audio to Telegram.

Build: push to GitHub -> Actions -> "Build Auto Voicemail APK" -> download app-debug.apk from Releases.
Setup in app: Telegram bot token + chat ID, START, enable Accessibility + Notification access, battery unrestricted.
Run ##002# once to switch off carrier voicemail.
