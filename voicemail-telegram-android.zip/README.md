# Voicemail → Telegram
1. Push to GitHub. Add repo secret FLY_API_TOKEN (`fly tokens create deploy`).
2. `fly launch --no-deploy --copy-config`; `fly volumes create vmdata --region bom --size 1`
3. `fly secrets set ...` (see .env.example); push to main to deploy.
4. In the Twilio console, set the number's Voice webhook to POST https://<app>.fly.dev/voice
5. Change greeting:
   curl -H "X-Admin-Token: $T" -F file=@new.mp3 https://<app>.fly.dev/admin/greeting
   curl -H "X-Admin-Token: $T" -H "Content-Type: application/json" -d '{"text":"नमस्ते..."}' https://<app>.fly.dev/admin/greeting-text

## Android app (control panel)
Push this repo to GitHub -> Actions -> "Build APK" -> download artifact `voicemail-control-apk` -> install app-debug.apk
(allow "install unknown apps"). Use it to dial the forwarding codes, upload an MP3, or regenerate the TTS greeting.
