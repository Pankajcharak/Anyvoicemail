import os, logging, threading, requests
from flask import Flask, request, Response, send_from_directory, abort, jsonify
from twilio.request_validator import RequestValidator
from twilio.twiml.voice_response import VoiceResponse

log = logging.getLogger("vm"); logging.basicConfig(level=logging.INFO)
app = Flask(__name__)

E = os.environ.get
BASE_URL   = E("BASE_URL", "").rstrip("/")          # e.g. https://my-vm.fly.dev
TW_SID, TW_TOKEN = E("TWILIO_ACCOUNT_SID"), E("TWILIO_AUTH_TOKEN")
TG_TOKEN, TG_CHAT = E("TELEGRAM_BOT_TOKEN"), E("TELEGRAM_CHAT_ID")
ADMIN_TOKEN = E("ADMIN_TOKEN")
DATA_DIR    = E("DATA_DIR", "./data"); os.makedirs(DATA_DIR, exist_ok=True)
GREETING    = os.path.join(DATA_DIR, "greeting.mp3")
DEFAULT_TEXT = E("GREETING_TEXT", "Hi, I'm currently unavailable. Please leave your message "
                 "after the beep. This call will be recorded.")
TTS_PROVIDER = E("TTS_PROVIDER", "azure")           # azure | elevenlabs | none
validator = RequestValidator(TW_TOKEN or "")

# ---------- greeting (file upload OR TTS) ----------
def make_tts(text: str) -> bool:
    try:
        if TTS_PROVIDER == "elevenlabs":
            r = requests.post(
                f"https://api.elevenlabs.io/v1/text-to-speech/{E('ELEVEN_VOICE_ID')}",
                headers={"xi-api-key": E("ELEVEN_API_KEY")},
                json={"text": text, "model_id": "eleven_multilingual_v2"}, timeout=60)
        elif TTS_PROVIDER == "azure":
            voice = E("AZURE_VOICE", "en-IN-NeerjaNeural")   # Hindi: hi-IN-SwaraNeural
            lang = voice[:5]
            ssml = (f"<speak version='1.0' xml:lang='{lang}'><voice name='{voice}'>"
                    f"{text}</voice></speak>")
            r = requests.post(
                f"https://{E('AZURE_REGION','centralindia')}.tts.speech.microsoft.com/cognitiveservices/v1",
                headers={"Ocp-Apim-Subscription-Key": E("AZURE_KEY"),
                         "Content-Type": "application/ssml+xml",
                         "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3"},
                data=ssml.encode("utf-8"), timeout=60)
        else:
            return False
        r.raise_for_status()
        open(GREETING, "wb").write(r.content)
        return True
    except Exception as ex:
        log.error("TTS failed: %s", ex); return False

if not os.path.exists(GREETING):
    make_tts(DEFAULT_TEXT)

def admin_only():
    if not ADMIN_TOKEN or request.headers.get("X-Admin-Token") != ADMIN_TOKEN:
        abort(403)

def twilio_only():
    url = BASE_URL + request.path
    if not validator.validate(url, request.form, request.headers.get("X-Twilio-Signature", "")):
        abort(403)

# ---------- Twilio webhooks ----------
@app.post("/voice")
def voice():
    twilio_only()
    vr = VoiceResponse()
    if os.path.exists(GREETING):
        vr.play(f"{BASE_URL}/greeting.mp3")
    else:
        vr.say(DEFAULT_TEXT, language="en-IN")
    vr.record(play_beep=True, max_length=180, timeout=4, trim="trim-silence",
              recording_status_callback=f"{BASE_URL}/recording",
              recording_status_callback_method="POST",
              recording_status_callback_event="completed")
    return Response(str(vr), mimetype="text/xml")

@app.post("/recording")
def recording():
    twilio_only()
    f = request.form
    threading.Thread(target=deliver, args=(
        f.get("RecordingUrl"), f.get("From", "unknown"),
        f.get("RecordingDuration", "0")), daemon=True).start()
    return ("", 204)

def deliver(url, caller, dur):
    try:
        if not url or int(dur) < 1:
            return
        audio = requests.get(url + ".mp3", auth=(TW_SID, TW_TOKEN), timeout=60).content
        requests.post(f"https://api.telegram.org/bot{TG_TOKEN}/sendAudio",
            data={"chat_id": TG_CHAT, "title": f"Voicemail {caller}",
                  "caption": f"📞 {caller}\n⏱ {dur}s"},
            files={"audio": (f"voicemail_{caller}.mp3", audio, "audio/mpeg")},
            timeout=120).raise_for_status()
    except Exception as ex:
        log.error("delivery failed: %s", ex)

@app.get("/greeting.mp3")
def greeting():
    return send_from_directory(DATA_DIR, "greeting.mp3", mimetype="audio/mpeg")

# ---------- admin: change greeting any time ----------
@app.post("/admin/greeting")          # curl -H "X-Admin-Token: x" -F file=@new.mp3 URL
def upload():
    admin_only(); request.files["file"].save(GREETING); return jsonify(ok=True)

@app.post("/admin/greeting-text")     # curl -H ... -d '{"text":"..."}' -H 'Content-Type: application/json'
def set_text():
    admin_only()
    ok = make_tts(request.get_json()["text"]); return jsonify(ok=ok)

@app.get("/health")
def health(): return "ok"
